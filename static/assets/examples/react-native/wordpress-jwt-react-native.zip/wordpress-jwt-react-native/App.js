import { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { getUser, hasSession, login, logout as endSession } from './api';

export default function App() {
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(true);

  async function run(action) {
    setError('');
    setBusy(true);
    try {
      await action();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }

  useEffect(() => {
    run(async () => {
      if (await hasSession()) setUser(await getUser());
    });
  }, []);

  function handleLogin() {
    run(async () => {
      await login(email.trim(), password);
      setPassword('');
      setUser(await getUser());
    });
  }

  function logout() {
    run(async () => {
      await endSession();
      setUser(null);
    });
  }

  return (
    <View style={styles.screen}>
      <View style={styles.card}>
        {user ? (
          <>
            <Text style={styles.title}>Hello, {user.name}</Text>
            <Button label="Log out" onPress={logout} disabled={busy} />
          </>
        ) : (
          <>
            <Text style={styles.title}>Log in</Text>
            <Text style={styles.label}>Email</Text>
            <TextInput
              style={styles.input}
              value={email}
              onChangeText={setEmail}
              autoCapitalize="none"
              autoComplete="email"
              keyboardType="email-address"
              textContentType="username"
            />
            <Text style={styles.label}>Password</Text>
            <TextInput
              style={styles.input}
              value={password}
              onChangeText={setPassword}
              secureTextEntry
              autoComplete="current-password"
              textContentType="password"
            />
            <Button label="Log in" onPress={handleLogin} disabled={busy} />
          </>
        )}
        {busy && <ActivityIndicator style={styles.spinner} />}
        {error ? (
          <Text style={styles.error} accessibilityRole="alert">
            {error}
          </Text>
        ) : null}
      </View>
    </View>
  );
}

function Button({ label, onPress, disabled }) {
  return (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      disabled={disabled}
      style={[styles.button, disabled && styles.buttonDisabled]}
    >
      <Text style={styles.buttonText}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, justifyContent: 'center', padding: 24, backgroundColor: '#f3f5f4' },
  card: { padding: 24, borderRadius: 12, backgroundColor: '#fff' },
  title: { marginBottom: 16, fontSize: 24, fontWeight: '700', color: '#17201b' },
  label: { marginBottom: 4, fontWeight: '600', color: '#17201b' },
  input: {
    marginBottom: 16,
    padding: 10,
    borderWidth: 1,
    borderColor: '#7c8a83',
    borderRadius: 6,
    fontSize: 16,
  },
  button: { alignItems: 'center', padding: 12, borderRadius: 6, backgroundColor: '#1d5e41' },
  buttonDisabled: { opacity: 0.6 },
  buttonText: { color: '#fff', fontWeight: '700' },
  spinner: { marginTop: 16 },
  error: { marginTop: 16, color: '#b42318' },
});

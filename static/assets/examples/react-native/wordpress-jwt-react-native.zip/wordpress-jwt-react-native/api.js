import * as SecureStore from 'expo-secure-store';

const WORDPRESS_URL = process.env.EXPO_PUBLIC_WORDPRESS_URL;
const JWT_KEY = 'wp_jwt';
const REFRESH_KEY = 'wp_refresh';

async function request(path, options) {
  let response;
  try {
    response = await fetch(`${WORDPRESS_URL}/wp-json${path}`, options);
  } catch {
    throw new Error('WordPress is unavailable.');
  }
  const body = await response.json().catch(() => null);
  if (response.status >= 500) throw new Error('WordPress is unavailable.');
  return { ok: response.ok, body };
}

async function expired() {
  await logout();
  return Object.assign(new Error('Your session expired. Log in again.'), { expired: true });
}

async function saveSession(data) {
  await SecureStore.setItemAsync(JWT_KEY, data.jwt);
  // refresh_token is only there when refresh tokens are turned on in WordPress.
  if (data.refresh_token) await SecureStore.setItemAsync(REFRESH_KEY, data.refresh_token);
  else await SecureStore.deleteItemAsync(REFRESH_KEY);
}

export async function hasSession() {
  return Boolean(await SecureStore.getItemAsync(JWT_KEY));
}

export async function logout() {
  await SecureStore.deleteItemAsync(JWT_KEY);
  await SecureStore.deleteItemAsync(REFRESH_KEY);
}

export async function login(email, password) {
  const { ok, body } = await request('/simple-jwt-login/v1/auth', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });
  if (!ok || !body?.data?.jwt) throw new Error('Login failed.');
  await saveSession(body.data);
}

let refreshing = null;

// Refresh tokens work once, so parallel calls must share one refresh request.
function refresh() {
  refreshing ??= (async () => {
    const refreshToken = await SecureStore.getItemAsync(REFRESH_KEY);
    if (!refreshToken) return false;
    const { ok, body } = await request('/simple-jwt-login/v1/auth/refresh', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refresh_token: refreshToken }),
    });
    if (!ok || !body?.data?.jwt) return false;
    await saveSession(body.data);
    return true;
  })().finally(() => {
    refreshing = null;
  });
  return refreshing;
}

async function authorized(path) {
  const send = async () =>
    request(path, { headers: { Authorization: `Bearer ${await SecureStore.getItemAsync(JWT_KEY)}` } });
  let result = await send();
  if (!result.ok && (await refresh())) result = await send();
  if (!result.ok) throw await expired();
  return result.body;
}

export async function getUser() {
  const user = await authorized('/wp/v2/users/me');
  if (typeof user?.name !== 'string') throw await expired();
  return user;
}

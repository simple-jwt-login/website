const WORDPRESS_URL = import.meta.env.VITE_WORDPRESS_URL;
const SESSION_KEY = 'wp_session';

async function request(path, options) {
  let response;
  try {
    response = await fetch(`${WORDPRESS_URL}/wp-json${path}`, options);
  } catch {
    throw new Error('WordPress is unavailable.');
  }
  const body = await response.json().catch(() => null);
  if (response.status >= 500) throw new Error('WordPress is unavailable.');
  return { ok: response.ok, body };
}

function expired() {
  logout();
  return Object.assign(new Error('Your session expired. Log in again.'), { expired: true });
}

function readSession() {
  try {
    return JSON.parse(sessionStorage.getItem(SESSION_KEY));
  } catch {
    return null;
  }
}

function saveSession(data) {
  // refresh_token is only there when refresh tokens are turned on in WordPress.
  sessionStorage.setItem(SESSION_KEY, JSON.stringify({ jwt: data.jwt, refreshToken: data.refresh_token }));
}

export function hasSession() {
  return Boolean(readSession()?.jwt);
}

export function logout() {
  sessionStorage.removeItem(SESSION_KEY);
}

export async function login(email, password) {
  const { ok, body } = await request('/simple-jwt-login/v1/auth', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });
  if (!ok || !body?.data?.jwt) throw new Error('Login failed.');
  saveSession(body.data);
}

let refreshing = null;

// Refresh tokens work once, so parallel calls must share one refresh request.
function refresh() {
  refreshing ??= (async () => {
    const refreshToken = readSession()?.refreshToken;
    if (!refreshToken) return false;
    const { ok, body } = await request('/simple-jwt-login/v1/auth/refresh', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refresh_token: refreshToken }),
    });
    if (!ok || !body?.data?.jwt) return false;
    saveSession(body.data);
    return true;
  })().finally(() => {
    refreshing = null;
  });
  return refreshing;
}

async function authorized(path) {
  const send = () => request(path, { headers: { Authorization: `Bearer ${readSession()?.jwt}` } });
  let result = await send();
  if (!result.ok && (await refresh())) result = await send();
  if (!result.ok) throw expired();
  return result.body;
}

export async function getUser() {
  const user = await authorized('/wp/v2/users/me');
  if (typeof user?.name !== 'string') throw expired();
  return user;
}

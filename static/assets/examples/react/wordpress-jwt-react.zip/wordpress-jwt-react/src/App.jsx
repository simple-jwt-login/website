import { useEffect, useState } from 'react';
import { getUser, hasSession, login, logout as endSession } from './api.js';

export default function App() {
  const [user, setUser] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(true);

  useEffect(() => {
    if (!hasSession()) {
      setBusy(false);
      return;
    }
    getUser()
      .then(setUser)
      .catch((e) => setError(e.message))
      .finally(() => setBusy(false));
  }, []);

  async function handleSubmit(event) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    setError('');
    setBusy(true);
    try {
      await login(form.get('email'), form.get('password'));
      setUser(await getUser());
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }

  function logout() {
    endSession();
    setUser(null);
  }

  if (user) {
    return (
      <main>
        <h1>Hello, {user.name}</h1>
        <button type="button" onClick={logout}>Log out</button>
      </main>
    );
  }

  return (
    <main>
      <h1>Log in</h1>
      <form method="post" onSubmit={handleSubmit}>
        <p>
          <label>
            Email{' '}
            <input name="email" type="email" autoComplete="username" required />
          </label>
        </p>
        <p>
          <label>
            Password{' '}
            <input
              name="password"
              type="password"
              autoComplete="current-password"
              required
            />
          </label>
        </p>
        <button type="submit" disabled={busy}>Log in</button>
        {error && <p role="alert">{error}</p>}
      </form>
    </main>
  );
}

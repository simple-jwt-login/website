import { Component, OnInit, inject, signal } from '@angular/core';
import { WordPressError, WordPressService, WordPressUser } from './wordpress.service';

@Component({
  selector: 'app-root',
  template: `
    <main>
      @if (user(); as user) {
        <h1>Hello, {{ user.name }}</h1>
        <button type="button" (click)="logout()">Log out</button>
      } @else {
        <h1>Log in</h1>
        <form method="post" (submit)="login($event)">
          <p>
            <label>
              Email
              <input name="email" type="email" autocomplete="username" required />
            </label>
          </p>
          <p>
            <label>
              Password
              <input name="password" type="password" autocomplete="current-password" required />
            </label>
          </p>
          <button type="submit" [disabled]="busy()">Log in</button>
          @if (error()) {
            <p role="alert">{{ error() }}</p>
          }
        </form>
      }
    </main>
  `,
})
export class App implements OnInit {
  private readonly wordpress = inject(WordPressService);
  protected readonly user = signal<WordPressUser | null>(null);
  protected readonly error = signal('');
  protected readonly busy = signal(true);

  async ngOnInit(): Promise<void> {
    if (this.wordpress.hasSession()) {
      await this.run(async () => this.user.set(await this.wordpress.getUser()));
    }
    this.busy.set(false);
  }

  protected async login(event: SubmitEvent): Promise<void> {
    event.preventDefault();
    const form = new FormData(event.target as HTMLFormElement);
    this.busy.set(true);
    await this.run(async () => {
      const email = String(form.get('email'));
      const password = String(form.get('password'));
      await this.wordpress.login(email, password);
      this.user.set(await this.wordpress.getUser());
    });
    this.busy.set(false);
  }

  protected logout(): void {
    this.wordpress.logout();
    this.user.set(null);
  }

  private async run(action: () => Promise<void>): Promise<void> {
    this.error.set('');
    try {
      await action();
    } catch (e) {
      const error =
        e instanceof WordPressError ? e : new WordPressError('Something went wrong. Try again.');
      this.error.set(error.message);
    }
  }
}

export const WORDPRESS_URL = 'https://example.com';

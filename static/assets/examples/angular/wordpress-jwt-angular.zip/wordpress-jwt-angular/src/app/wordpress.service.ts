import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, firstValueFrom } from 'rxjs';
import { WORDPRESS_URL } from './wordpress.config';

export interface WordPressUser {
  id: number;
  name: string;
}

interface TokenResponse {
  data?: { jwt?: string; refresh_token?: string };
}

interface Session {
  jwt: string;
  refreshToken?: string;
}

const SESSION_KEY = 'wp_session';

export class WordPressError extends Error {
  constructor(
    message: string,
    readonly expired = false,
  ) {
    super(message);
  }
}

@Injectable({ providedIn: 'root' })
export class WordPressService {
  private readonly http = inject(HttpClient);
  private refreshing: Promise<boolean> | null = null;

  hasSession(): boolean {
    return Boolean(this.readSession()?.jwt);
  }

  logout(): void {
    sessionStorage.removeItem(SESSION_KEY);
  }

  async login(email: string, password: string): Promise<void> {
    const url = `${WORDPRESS_URL}/wp-json/simple-jwt-login/v1/auth`;
    const body = await this.send(this.http.post<TokenResponse>(url, { email, password }), 'Login failed.');
    if (!body.data?.jwt) throw new WordPressError('Login failed.');
    this.saveSession(body.data);
  }

  async getUser(): Promise<WordPressUser> {
    const url = `${WORDPRESS_URL}/wp-json/wp/v2/users/me`;
    const get = () =>
      this.send(
        this.http.get<WordPressUser>(url, {
          headers: { Authorization: `Bearer ${this.readSession()?.jwt}` },
        }),
        'Your session expired. Log in again.',
        true,
      );
    try {
      return await get();
    } catch (error) {
      if (!(error instanceof WordPressError) || !error.expired) throw error;
      if (!(await this.refresh())) throw this.expired();
      return get().catch(() => Promise.reject(this.expired()));
    }
  }

  // Refresh tokens work once, so parallel calls must share one refresh request.
  private refresh(): Promise<boolean> {
    this.refreshing ??= (async () => {
      const refreshToken = this.readSession()?.refreshToken;
      if (!refreshToken) return false;
      const url = `${WORDPRESS_URL}/wp-json/simple-jwt-login/v1/auth/refresh`;
      try {
        const body = await this.send(
          this.http.post<TokenResponse>(url, { refresh_token: refreshToken }),
          'Refresh failed.',
          true,
        );
        if (!body.data?.jwt) return false;
        this.saveSession(body.data);
        return true;
      } catch (error) {
        if (error instanceof WordPressError && error.expired) return false;
        throw error;
      }
    })().finally(() => (this.refreshing = null));
    return this.refreshing;
  }

  private expired(): WordPressError {
    this.logout();
    return new WordPressError('Your session expired. Log in again.', true);
  }

  private readSession(): Session | null {
    try {
      return JSON.parse(sessionStorage.getItem(SESSION_KEY) ?? 'null');
    } catch {
      return null;
    }
  }

  // refresh_token is only there when refresh tokens are turned on in WordPress.
  private saveSession(data: { jwt?: string; refresh_token?: string }): void {
    const session: Session = { jwt: data.jwt ?? '', refreshToken: data.refresh_token };
    sessionStorage.setItem(SESSION_KEY, JSON.stringify(session));
  }

  private async send<T>(request: Observable<T>, message: string, expired = false): Promise<T> {
    try {
      return await firstValueFrom(request);
    } catch (error) {
      if (error instanceof HttpErrorResponse && (error.status === 0 || error.status >= 500)) {
        throw new WordPressError('WordPress is unavailable.');
      }
      throw new WordPressError(message, expired);
    }
  }
}

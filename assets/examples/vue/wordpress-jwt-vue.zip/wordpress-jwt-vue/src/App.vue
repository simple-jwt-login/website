<script setup>
import { onMounted, ref } from 'vue';
import { getUser, hasSession, login, logout as endSession } from './api.js';

const user = ref(null);
const error = ref('');
const busy = ref(true);

async function run(action) {
  error.value = '';
  busy.value = true;
  try {
    await action();
  } catch (e) {
    error.value = e.message;
  } finally {
    busy.value = false;
  }
}

onMounted(() => {
  if (!hasSession()) {
    busy.value = false;
    return;
  }
  run(async () => {
    user.value = await getUser();
  });
});

function handleSubmit(event) {
  const form = new FormData(event.currentTarget);
  run(async () => {
    await login(form.get('email'), form.get('password'));
    user.value = await getUser();
  });
}

function logout() {
  endSession();
  user.value = null;
}
</script>

<template>
  <main v-if="user">
    <h1>Hello, {{ user.name }}</h1>
    <button type="button" @click="logout">Log out</button>
  </main>
  <main v-else>
    <h1>Log in</h1>
    <form method="post" @submit.prevent="handleSubmit">
      <p>
        <label>
          Email
          <input name="email" type="email" autocomplete="username" required />
        </label>
      </p>
      <p>
        <label>
          Password
          <input name="password" type="password" autocomplete="current-password" required />
        </label>
      </p>
      <button type="submit" :disabled="busy">Log in</button>
      <p v-if="error" role="alert">{{ error }}</p>
    </form>
  </main>
</template>

import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import 'wordpress_api.dart';

const _wordPressUrl = String.fromEnvironment(
  'WORDPRESS_URL',
  defaultValue: 'https://example.com',
);

void main() {
  runApp(MyApp(api: WordPressApi(baseUrl: _wordPressUrl)));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key, required this.api});

  final WordPressApi api;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'WordPress JWT Login',
      theme: ThemeData(colorSchemeSeed: const Color(0xFF1D5E41)),
      home: HomePage(api: api),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key, required this.api});

  final WordPressApi api;

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  static const _storage = FlutterSecureStorage();
  static const _jwtKey = 'wp_jwt';
  static const _refreshKey = 'wp_refresh';

  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _loading = true;
  String? _error;
  String? _name;

  @override
  void initState() {
    super.initState();
    _run(_restore);
  }

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _run(Future<void> Function() action) async {
    setState(() {
      _loading = true;
      _error = null;
    });
    String? error;
    try {
      await action();
    } on ApiException catch (e) {
      error = e.message;
    } catch (_) {
      error = 'Something went wrong. Try again.';
    }
    if (!mounted) return;
    setState(() {
      _loading = false;
      _error = error;
    });
  }

  Future<void> _restore() async {
    if (await _storage.read(key: _jwtKey) != null) _name = await _userName();
  }

  Future<void> _login() async {
    await _save(await widget.api.login(_email.text.trim(), _password.text));
    _password.clear();
    _name = await _userName();
  }

  Future<void> _logout() async {
    await _storage.delete(key: _jwtKey);
    await _storage.delete(key: _refreshKey);
    _name = null;
  }

  Future<void> _save(Tokens tokens) async {
    await _storage.write(key: _jwtKey, value: tokens.jwt);
    await _storage.write(key: _refreshKey, value: tokens.refreshToken);
  }

  /// Loads the user, refreshing the JWT once if it expired.
  Future<String> _userName() async {
    try {
      try {
        return await widget.api.userName(await _storage.read(key: _jwtKey) ?? '');
      } on SessionExpiredException {
        final refreshToken = await _storage.read(key: _refreshKey);
        if (refreshToken == null) rethrow;
        await _save(await widget.api.refresh(refreshToken));
        return await widget.api.userName(await _storage.read(key: _jwtKey) ?? '');
      }
    } on SessionExpiredException {
      await _logout();
      rethrow;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 360),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    _name == null ? 'Log in' : 'Hello, $_name',
                    style: Theme.of(context).textTheme.headlineMedium,
                  ),
                  const SizedBox(height: 24),
                  if (_name == null) ..._loginFields(),
                  FilledButton(
                    onPressed: _loading
                        ? null
                        : () => _run(_name == null ? _login : _logout),
                    child: Text(_name == null ? 'Log in' : 'Log out'),
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 16),
                    Text(
                      _error!,
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.error,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  List<Widget> _loginFields() {
    return [
      TextField(
        controller: _email,
        keyboardType: TextInputType.emailAddress,
        autocorrect: false,
        decoration: const InputDecoration(
          labelText: 'Email',
          border: OutlineInputBorder(),
        ),
      ),
      const SizedBox(height: 16),
      TextField(
        controller: _password,
        obscureText: true,
        decoration: const InputDecoration(
          labelText: 'Password',
          border: OutlineInputBorder(),
        ),
      ),
      const SizedBox(height: 16),
    ];
  }
}

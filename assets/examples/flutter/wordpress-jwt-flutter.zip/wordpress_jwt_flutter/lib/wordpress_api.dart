import 'dart:convert';

import 'package:http/http.dart' as http;

class ApiException implements Exception {
  const ApiException(this.message);

  final String message;
}

/// The JWT or refresh token was rejected: refresh or log in again.
class SessionExpiredException extends ApiException {
  const SessionExpiredException() : super('Your session expired. Log in again.');
}

class Tokens {
  const Tokens(this.jwt, this.refreshToken);

  final String jwt;

  /// Only there when refresh tokens are turned on in WordPress.
  final String? refreshToken;
}

class WordPressApi {
  WordPressApi({required this.baseUrl, http.Client? client})
      : _client = client ?? http.Client();

  final String baseUrl;
  final http.Client _client;

  static const _timeout = Duration(seconds: 15);

  /// Returns the tokens for the given WordPress credentials.
  Future<Tokens> login(String email, String password) async {
    final body = await _send(
      () => _client.post(
        Uri.parse('$baseUrl/wp-json/simple-jwt-login/v1/auth'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'email': email, 'password': password}),
      ),
    );
    return _tokens(body) ?? (throw const ApiException('Login failed.'));
  }

  /// Swaps a refresh token for new tokens. Each refresh token works once.
  Future<Tokens> refresh(String refreshToken) async {
    final body = await _send(
      () => _client.post(
        Uri.parse('$baseUrl/wp-json/simple-jwt-login/v1/auth/refresh'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'refresh_token': refreshToken}),
      ),
    );
    return _tokens(body) ?? (throw const SessionExpiredException());
  }

  /// Returns the display name of the logged-in user.
  Future<String> userName(String jwt) async {
    final body = await _send(
      () => _client.get(
        Uri.parse('$baseUrl/wp-json/wp/v2/users/me'),
        headers: {'Authorization': 'Bearer $jwt'},
      ),
    );
    if (body case {'name': final String name}) return name;
    throw const SessionExpiredException();
  }

  Tokens? _tokens(Object? body) {
    if (body case {'data': {'jwt': final String jwt}}) {
      final data = (body as Map)['data'] as Map;
      return Tokens(jwt, data['refresh_token'] as String?);
    }
    return null;
  }

  Future<Object?> _send(Future<http.Response> Function() request) async {
    try {
      final response = await request().timeout(_timeout);
      // A server error is an outage, not an expired session.
      if (response.statusCode >= 500) throw const ApiException('WordPress is unavailable.');
      return jsonDecode(utf8.decode(response.bodyBytes));
    } catch (_) {
      throw const ApiException('WordPress is unavailable.');
    }
  }
}

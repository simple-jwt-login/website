import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:wordpress_jwt_flutter/main.dart';
import 'package:wordpress_jwt_flutter/wordpress_api.dart';

WordPressApi fakeApi() {
  return WordPressApi(
    baseUrl: 'https://example.com',
    client: MockClient((request) async {
      if (request.url.path.endsWith('/auth/refresh')) {
        return request.body.contains('"r1"')
            ? http.Response('{"success":true,"data":{"jwt":"abc","refresh_token":"r2"}}', 200)
            : http.Response('{"success":false,"data":{"error_code":51}}', 401);
      }
      if (request.url.path.endsWith('/auth')) {
        return request.body.contains('"secret"')
            ? http.Response('{"success":true,"data":{"jwt":"abc"}}', 200)
            : http.Response('{"success":false,"data":{"error_code":48}}', 401);
      }
      return request.headers['Authorization'] == 'Bearer abc'
          ? http.Response('{"name":"Jane"}', 200)
          : http.Response('{"code":"rest_not_logged_in"}', 401);
    }),
  );
}

Future<void> logIn(WidgetTester tester, String password) async {
  await tester.enterText(find.byType(TextField).first, 'jane@example.com');
  await tester.enterText(find.byType(TextField).last, password);
  await tester.tap(find.byType(FilledButton));
  await tester.pumpAndSettle();
}

void main() {
  setUp(() => FlutterSecureStorage.setMockInitialValues({}));

  testWidgets('logs in and out', (tester) async {
    await tester.pumpWidget(MyApp(api: fakeApi()));
    await tester.pumpAndSettle();
    await logIn(tester, 'secret');
    expect(find.text('Hello, Jane'), findsOneWidget);

    await tester.tap(find.text('Log out'));
    await tester.pumpAndSettle();
    expect(find.byType(TextField), findsNWidgets(2));
  });

  testWidgets('shows an error for a wrong password', (tester) async {
    await tester.pumpWidget(MyApp(api: fakeApi()));
    await tester.pumpAndSettle();
    await logIn(tester, 'wrong');
    expect(find.text('Login failed.'), findsOneWidget);
  });

  testWidgets('restores a saved session', (tester) async {
    FlutterSecureStorage.setMockInitialValues({'wp_jwt': 'abc'});
    await tester.pumpWidget(MyApp(api: fakeApi()));
    await tester.pumpAndSettle();
    expect(find.text('Hello, Jane'), findsOneWidget);
  });

  testWidgets('refreshes an expired JWT', (tester) async {
    FlutterSecureStorage.setMockInitialValues({'wp_jwt': 'old', 'wp_refresh': 'r1'});
    await tester.pumpWidget(MyApp(api: fakeApi()));
    await tester.pumpAndSettle();
    expect(find.text('Hello, Jane'), findsOneWidget);
    expect(await const FlutterSecureStorage().read(key: 'wp_refresh'), 'r2');
  });

  testWidgets('logs out when the refresh token is rejected', (tester) async {
    FlutterSecureStorage.setMockInitialValues({'wp_jwt': 'old', 'wp_refresh': 'used'});
    await tester.pumpWidget(MyApp(api: fakeApi()));
    await tester.pumpAndSettle();
    expect(find.text('Your session expired. Log in again.'), findsOneWidget);
    expect(await const FlutterSecureStorage().read(key: 'wp_jwt'), isNull);
  });

  test('reports an unreachable site', () {
    final api = WordPressApi(
      baseUrl: 'https://example.com',
      client: MockClient((_) async => http.Response('<html>', 502)),
    );
    expect(() => api.login('a', 'b'), throwsA(isA<ApiException>()));
  });

  test('keeps the session when WordPress fails', () {
    final api = WordPressApi(
      baseUrl: 'https://example.com',
      client: MockClient((_) async => http.Response('{"code":"internal_server_error"}', 500)),
    );
    expect(
      () => api.userName('abc'),
      throwsA(isA<ApiException>().having((e) => e is SessionExpiredException, 'expired', false)),
    );
  });
}

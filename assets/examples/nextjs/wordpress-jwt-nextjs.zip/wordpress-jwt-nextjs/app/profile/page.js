import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import LogoutButton from './logout-button';

export default async function ProfilePage({ searchParams }) {
  const token = (await cookies()).get('wp_jwt')?.value;
  if (!token) redirect('/login');

  const url = `${process.env.WORDPRESS_URL}/wp-json/wp/v2/users/me`;
  const response = await fetch(url, {
    headers: { Authorization: `Bearer ${token}` },
    cache: 'no-store',
  });
  if (response.status >= 500) throw new Error('WordPress is unavailable.');
  // An expired or invalid JWT: try the refresh token once.
  if (!response.ok && !(await searchParams).refreshed) redirect('/api/refresh');
  if (!response.ok) redirect('/login');

  const user = await response.json();
  return (
    <main>
      <h1>Hello, {user.name}</h1>
      <LogoutButton />
    </main>
  );
}

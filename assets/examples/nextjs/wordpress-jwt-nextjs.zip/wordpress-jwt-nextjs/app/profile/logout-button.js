'use client';

import { useState } from 'react';

export default function LogoutButton() {
  const [error, setError] = useState('');

  async function handleClick() {
    try {
      const response = await fetch('/api/logout', { method: 'POST' });
      if (!response.ok) throw new Error('Logout failed');
      window.location.assign('/login');
    } catch {
      setError('Logout failed. Try again.');
    }
  }

  return (
    <>
      <button type="button" onClick={handleClick}>
        Log out
      </button>
      {error && <p role="alert">{error}</p>}
    </>
  );
}

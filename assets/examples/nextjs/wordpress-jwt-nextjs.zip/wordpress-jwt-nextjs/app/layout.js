import './globals.css';

export const metadata = { title: 'WordPress JWT Login' };

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}

'use client';

import { useState } from 'react';

export default function LoginPage() {
  const [error, setError] = useState('');

  async function handleSubmit(event) {
    event.preventDefault();
    setError('');
    const form = new FormData(event.currentTarget);

    try {
      const response = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: form.get('email'),
          password: form.get('password'),
        }),
      });
      if (response.ok) {
        window.location.assign('/profile');
        return;
      }
      const result = await response.json();
      setError(result.message);
    } catch {
      setError('Something went wrong. Try again.');
    }
  }

  return (
    <main>
      <h1>Log in</h1>
      <form method="post" onSubmit={handleSubmit}>
        <p>
          <label>
            Email{' '}
            <input name="email" type="email" autoComplete="username" required />
          </label>
        </p>
        <p>
          <label>
            Password{' '}
            <input
              name="password"
              type="password"
              autoComplete="current-password"
              required
            />
          </label>
        </p>
        <button type="submit">Log in</button>
        {error && <p role="alert">{error}</p>}
      </form>
    </main>
  );
}

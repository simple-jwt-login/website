import { cookies } from 'next/headers';
import { saveSession } from '../../lib/session';

export async function POST(request) {
  const { email, password } = (await request.json().catch(() => null)) ?? {};
  if (typeof email !== 'string' || typeof password !== 'string') {
    return Response.json(
      { message: 'Email and password are required.' },
      { status: 400 }
    );
  }

  const url = `${process.env.WORDPRESS_URL}/wp-json/simple-jwt-login/v1/auth`;
  let response;
  let result;
  try {
    response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
      cache: 'no-store',
    });
    result = await response.json();
  } catch (error) {
    console.error('WordPress login request failed', error);
    return Response.json(
      { message: 'WordPress is unavailable.' },
      { status: 502 }
    );
  }

  if (!response.ok || !result?.data?.jwt) {
    return Response.json({ message: 'Login failed.' }, { status: 401 });
  }

  saveSession(await cookies(), result.data);
  return Response.json({ success: true });
}

import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { clearSession, saveSession } from '../../lib/session';

// Pages can't set cookies, so the profile page sends expired sessions here to swap the refresh token.
export async function GET() {
  const cookieStore = await cookies();
  const refreshToken = cookieStore.get('wp_refresh')?.value;

  let result;
  if (refreshToken) {
    const url = `${process.env.WORDPRESS_URL}/wp-json/simple-jwt-login/v1/auth/refresh`;
    let response;
    try {
      response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refresh_token: refreshToken }),
        cache: 'no-store',
      });
    } catch (error) {
      console.error('WordPress refresh request failed', error);
    }
    // Keep the session when WordPress is down, so the user isn't logged out.
    if (!response || response.status >= 500) {
      return Response.json({ message: 'WordPress is unavailable.' }, { status: 502 });
    }
    result = response.ok ? await response.json().catch(() => null) : null;
  }

  if (!result?.data?.jwt) {
    clearSession(cookieStore);
    redirect('/login');
  }
  saveSession(cookieStore, result.data);
  redirect('/profile?refreshed=1');
}

import { cookies } from 'next/headers';
import { clearSession } from '../../lib/session';

export async function POST() {
  clearSession(await cookies());
  return Response.json({ success: true });
}
